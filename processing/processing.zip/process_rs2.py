# -*- coding: utf-8 -*-
"""
Created on Sat Oct 10 12:13:06 2020

@author: Florian BIROT - FB SOLUTIONS
"""

import numpy as np
import pandas as pd

ref_e, ref_n, ref_h = 653995.3696, 6858817.8121, 114.2324 # from static results
ref_e_utm, ref_n_utm = 31454007.5129, 5408500.0877 # idem

# displaying session details
print('##########################################################')
print('#                                                        #')
print('# Positioning session with the Reach RS2 by FB SOLUTIONS #')
print('#                                                        #')
print('##########################################################')


# Static session
print('\n')
print('##################### Static post-process ####################')

# loading baselines data
baselines = pd.read_csv(r'static_baselines.txt', delim_whitespace=True)

# building planimetric gaps
baselines['dp'] = np.sqrt(baselines.de**2 + baselines.dn**2)

# Standard deviation of the results
print(f' ## Std dev Eastings     : {baselines.de.std():>.1f} mm\n')
print(f' ## Std dev Northings    : {baselines.dn.std():>.1f} mm\n')
print(f' ## Std dev Height       : {baselines.dh.std():>.1f} mm\n')

# PPK session
print('\n')
print('##################### PPK session ####################')

# loading position data
ppk = pd.read_csv('STAT_ppk.pos')

# set time index
ppk['time'] = pd.to_datetime(ppk.time)
ppk.set_index('time', inplace=True)

# compute distances to ref coordinates
ppk['de'] = ppk.e-ref_e_utm
ppk['dn'] = ppk.n-ref_n_utm
ppk['dh'] = ppk.h-ref_h

# fixed data
fix_ppk = ppk.loc[ppk.solution == 'Fixed']

print(f'\n# From : {ppk.iloc[0].name}')
print(f'# To   : {ppk.iloc[-1].name}')

# statistics on the fixed observations

## on the fixed ratio
f_ratio = len(fix_ppk) / len(ppk)
print(f'\n# Fixed positioning rate  : {100*f_ratio:.1f}%')

## on the 3 coordinates
print(f'\n# Average PPK position - RGF93 UTM31\n')
### Eastings
std_e = fix_ppk.e.std()
avg_e = fix_ppk.e.mean()
print(f' ## Avg Eastings     : {avg_e:>13.4f} ± {100*std_e:.1f} cm')
print(f' ##                    {abs(100*(avg_e-ref_e_utm)):>.1f} cm from ref\n')
### Northings
std_n = fix_ppk.n.std()
avg_n = fix_ppk.n.mean()
print(f' ## Avg Northings    : {avg_n:>13.4f} ± {100*std_n:.1f} cm')
print(f' ##                    {abs(100*(avg_n-ref_n_utm)):>.1f} cm from ref\n')
### Height
std_h = fix_ppk.h.std()
avg_h = fix_ppk.h.mean()
print(f' ## Avg Height (GRS80) : {avg_h:>13.4f} ± {100*std_h:.1f} cm')
print(f' ##                    {abs(100*(avg_h-ref_h)):>.1f} cm from ref\n')

## on the satellites in use
print(f'\n# Number of satellites in use\n')
min_s = fix_ppk.nb_fixed_sat.min()
avg_s = fix_ppk.nb_fixed_sat.mean()
max_s = fix_ppk.nb_fixed_sat.max()
print(f' ## Min sat num  : {min_s:>}')
print(f' ## Avg sat num  : {avg_s:>.1f}')
print(f' ## Max sat num  : {max_s:>}')


# Kinematic PPP session
print('\n')
print('################## Kinematic PPP session #################')

# loading position data
ppp = pd.read_csv('STAT_ppp_kinematic.pos', delim_whitespace=True)

# set time index
ppp['time'] = pd.to_datetime(ppp.time)
ppp.set_index('time', inplace=True)

# compute distances to ref coordinates
ppp['de'] = ppp.e-ref_e_utm
ppp['dn'] = ppp.n-ref_n_utm
ppp['dh'] = ppp.h-ref_h

print(f'\n# From : {ppp.iloc[0].name}')
print(f'# To   : {ppp.iloc[-1].name}')

# statistics on the observations

## on the 3 coordinates
print(f'\n# Average PPP position - RGF93 UTM31\n')
### Eastings
std_e = ppp.e.std()
avg_e = ppp.e.mean()
print(f' ## Avg Eastings     : {avg_e:>13.4f} ± {100*std_e:.1f} cm')
print(f' ##                    {abs(100*(avg_e-ref_e_utm)):>.1f} cm from ref\n')
### Northings
std_n = ppp.n.std()
avg_n = ppp.n.mean()
print(f' ## Avg Northings    : {avg_n:>13.4f} ± {100*std_n:.1f} cm')
print(f' ##                    {abs(100*(avg_n-ref_n_utm)):>.1f} cm from ref\n')
### Height
std_h = ppp.h.std()
avg_h = ppp.h.mean()
print(f' ## Avg Height (GRS80) : {avg_h:>13.4f} ± {100*std_h:.1f} cm')
print(f' ##                    {abs(100*(avg_h-ref_h)):>.1f} cm from ref\n')

## on the satellites in use
print(f'\n# Number of satellites in use\n')
min_s = ppp['#all'].min()
avg_s = ppp['#all'].mean()
max_s = ppp['#all'].max()
print(f' ## Min sat num  : {min_s:>}')
print(f' ## Avg sat num  : {avg_s:>.1f}')
print(f' ## Max sat num  : {max_s:>}')



# NRTK session
print('\n')
print('############## Average of NRTK positions #################')
# loading position data
pos = pd.read_csv("solution_202010070514.ENH", delim_whitespace=True)

# set time index
pos['time'] = pd.to_datetime(pos.time)
pos.set_index('time', inplace=True)

# compute distances to ref coordinates
pos['de'] = pos.e-ref_e
pos['dn'] = pos.n-ref_n
pos['dh'] = pos.h-ref_h

# fixed data
fix_pos = pos.loc[pos.q == 1]

print(f'\n# From : {pos.iloc[0].name}')
print(f'# To   : {pos.iloc[-1].name}')

# statistics on the fixed observations

## on the fixed ratio
f_ratio = len(fix_pos) / len(pos)
print(f'\n# Fixed positioning rate  : {100*f_ratio:.1f}%')

## on the 3 coordinates
print(f'\n# Average RTK position - RGF93 Lambert93\n')
### Eastings
std_e = fix_pos.e.std()
avg_e = fix_pos.e.mean()
print(f' ## Avg Eastings     : {avg_e:>13.4f} ± {100*std_e:.1f} cm')
print(f' ##                    {abs(100*(avg_e-ref_e)):>.1f} cm from ref\n')
### Northings
std_n = fix_pos.n.std()
avg_n = fix_pos.n.mean()
print(f' ## Avg Northings    : {avg_n:>13.4f} ± {100*std_n:.1f} cm')
print(f' ##                    {abs(100*(avg_n-ref_n)):>.1f} cm from ref\n')
### Height
std_h = fix_pos.h.std()
avg_h = fix_pos.h.mean()
print(f' ## Avg Height (GRS80) : {avg_h:>13.4f} ± {100*std_h:.1f} cm')
print(f' ##                    {abs(100*(avg_h-ref_h)):>.1f} cm from ref\n')

## on the satellites in use
print(f'\n# Number of satellites in use\n')
min_s = fix_pos.ns.min()
avg_s = fix_pos.ns.mean()
max_s = fix_pos.ns.max()
print(f' ## Min sat num  : {min_s:>}')
print(f' ## Avg sat num  : {avg_s:>.1f}')
print(f' ## Max sat num  : {max_s:>}')
