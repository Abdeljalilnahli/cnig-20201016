# -*- coding: utf-8 -*-
"""
Created on Sat Oct 10 12:13:06 2020

@author: Florian BIROT - FB SOLUTIONS
"""

import numpy as np
import pandas as pd

ref_e, ref_n, ref_h = 653995.3696, 6858817.8121, 114.2324 # from static results

# displaying session details
print('##########################################################')
print('#                                                        #')
print('# Positioning session with the Reach RS2 by FB SOLUTIONS #')
print('#                                                        #')
print('##########################################################')

# NRTK session
print('\n')
print('############## Average of NRTK positions #################')
# loading position data
pos = pd.read_csv("solution_202010070514.ENH", delim_whitespace=True)

# set time index
pos['time'] = pd.to_datetime(pos.time)
pos.set_index('time', inplace=True)

# compute distances to ref coordinates
pos['de'] = pos.e-ref_e
pos['dn'] = pos.n-ref_n
pos['dh'] = pos.h-ref_h

# fixed data
fix_pos = pos.loc[pos.q == 1]

print(f'\n# From : {pos.iloc[0].name}')
print(f'# To   : {pos.iloc[-1].name}')

# statistics on the fixed observations

## on the fixed ratio
f_ratio = len(fix_pos) / len(pos)
print(f'\n# Fixed positioning rate  : {100*f_ratio:.1f}%')

## on the 3 coordinates
print(f'\n# Average RTK position - RGF93 Lambert93\n')
### Eastings
std_e = fix_pos.e.std()
avg_e = fix_pos.e.mean()
print(f' ## Avg Eastings     : {avg_e:>13.4f} ± {100*std_e:.1f} cm')
print(f' ##                    {abs(100*(avg_e-ref_e)):>.1f} cm from ref\n')
### Northings
std_n = fix_pos.n.std()
avg_n = fix_pos.n.mean()
print(f' ## Avg Northings    : {avg_n:>13.4f} ± {100*std_n:.1f} cm')
print(f' ##                    {abs(100*(avg_n-ref_n)):>.1f} cm from ref\n')
### Height
std_h = fix_pos.h.std()
avg_h = fix_pos.h.mean()
print(f' ## Avg Height (GRS80) : {avg_h:>13.4f} ± {100*std_h:.1f} cm')
print(f' ##                    {abs(100*(avg_h-ref_h)):>.1f} cm from ref\n')

## on the satellites in use
print(f'\n# Number of satellites in use\n')
min_s = fix_pos.ns.min()
avg_s = fix_pos.ns.mean()
max_s = fix_pos.ns.max()
print(f' ## Min sat num  : {min_s:>}')
print(f' ## Avg sat num  : {avg_s:>.1f}')
print(f' ## Max sat num  : {max_s:>}')

# Static session
print('\n')
print('##################### Static post-process ####################')

# loading baselines data
baselines = pd.read_csv(r'ppk_baselines.txt', delim_whitespace=True)

# building planimetric gaps
baselines['dp'] = np.sqrt(baselines.de**2 + baselines.dn**2)

# Standard deviation of the results
print(f' ## Std dev Eastings     : {baselines.de.std():>.1f} mm\n')
print(f' ## Std dev Northings    : {baselines.dn.std():>.1f} mm\n')
print(f' ## Std dev Height       : {baselines.dh.std():>.1f} mm\n')
